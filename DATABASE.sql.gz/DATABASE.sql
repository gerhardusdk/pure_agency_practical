# WordPress MySQL database migration
#
# Generated: Tuesday 31. January 2023 18:07 UTC
# Hostname: localhost:8889
# Database: `apollo`
# URL: //www.apollo-blinds.co.uk
# Path: /Applications/MAMP/htdocs/2022/apollo2023
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_yoast_indexable, wp_yoast_indexable_hierarchy, wp_yoast_migrations, wp_yoast_primary_term, wp_yoast_seo_links
# Table Prefix: wp_
# Post Types: revision, acf-field-group, attachment, featured-banners, our-faqs, our-socials, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2023-01-30 14:52:41', '2023-01-30 12:52:41', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1022 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://www.apollo-blinds.co.uk', 'yes'),
(2, 'home', 'http://www.apollo-blinds.co.uk', 'yes'),
(3, 'blogname', 'Apollo Shutters', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'gerhard@launchsite.co.za', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'j F Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:149:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:39:"index.php?yoast-sitemap-xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:19:"featured-banners/?$";s:36:"index.php?post_type=featured-banners";s:49:"featured-banners/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?post_type=featured-banners&feed=$matches[1]";s:44:"featured-banners/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?post_type=featured-banners&feed=$matches[1]";s:36:"featured-banners/page/([0-9]{1,})/?$";s:54:"index.php?post_type=featured-banners&paged=$matches[1]";s:11:"our-faqs/?$";s:28:"index.php?post_type=our-faqs";s:41:"our-faqs/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=our-faqs&feed=$matches[1]";s:36:"our-faqs/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=our-faqs&feed=$matches[1]";s:28:"our-faqs/page/([0-9]{1,})/?$";s:46:"index.php?post_type=our-faqs&paged=$matches[1]";s:14:"our-socials/?$";s:31:"index.php?post_type=our-socials";s:44:"our-socials/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=our-socials&feed=$matches[1]";s:39:"our-socials/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=our-socials&feed=$matches[1]";s:31:"our-socials/page/([0-9]{1,})/?$";s:49:"index.php?post_type=our-socials&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:42:"featured-banners/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:52:"featured-banners/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:72:"featured-banners/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"featured-banners/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"featured-banners/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:"featured-banners/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:31:"featured-banners/(.+?)/embed/?$";s:49:"index.php?featured-banners=$matches[1]&embed=true";s:35:"featured-banners/(.+?)/trackback/?$";s:43:"index.php?featured-banners=$matches[1]&tb=1";s:55:"featured-banners/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?featured-banners=$matches[1]&feed=$matches[2]";s:50:"featured-banners/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?featured-banners=$matches[1]&feed=$matches[2]";s:43:"featured-banners/(.+?)/page/?([0-9]{1,})/?$";s:56:"index.php?featured-banners=$matches[1]&paged=$matches[2]";s:50:"featured-banners/(.+?)/comment-page-([0-9]{1,})/?$";s:56:"index.php?featured-banners=$matches[1]&cpage=$matches[2]";s:39:"featured-banners/(.+?)(?:/([0-9]+))?/?$";s:55:"index.php?featured-banners=$matches[1]&page=$matches[2]";s:34:"our-faqs/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"our-faqs/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"our-faqs/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"our-faqs/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"our-faqs/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"our-faqs/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"our-faqs/(.+?)/embed/?$";s:41:"index.php?our-faqs=$matches[1]&embed=true";s:27:"our-faqs/(.+?)/trackback/?$";s:35:"index.php?our-faqs=$matches[1]&tb=1";s:47:"our-faqs/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?our-faqs=$matches[1]&feed=$matches[2]";s:42:"our-faqs/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?our-faqs=$matches[1]&feed=$matches[2]";s:35:"our-faqs/(.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?our-faqs=$matches[1]&paged=$matches[2]";s:42:"our-faqs/(.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?our-faqs=$matches[1]&cpage=$matches[2]";s:31:"our-faqs/(.+?)(?:/([0-9]+))?/?$";s:47:"index.php?our-faqs=$matches[1]&page=$matches[2]";s:37:"our-socials/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"our-socials/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"our-socials/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"our-socials/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"our-socials/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"our-socials/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"our-socials/(.+?)/embed/?$";s:44:"index.php?our-socials=$matches[1]&embed=true";s:30:"our-socials/(.+?)/trackback/?$";s:38:"index.php?our-socials=$matches[1]&tb=1";s:50:"our-socials/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?our-socials=$matches[1]&feed=$matches[2]";s:45:"our-socials/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?our-socials=$matches[1]&feed=$matches[2]";s:38:"our-socials/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?our-socials=$matches[1]&paged=$matches[2]";s:45:"our-socials/(.+?)/comment-page-([0-9]{1,})/?$";s:51:"index.php?our-socials=$matches[1]&cpage=$matches[2]";s:34:"our-socials/(.+?)(?:/([0-9]+))?/?$";s:50:"index.php?our-socials=$matches[1]&page=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=8&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:33:"classic-editor/classic-editor.php";i:1;s:32:"duplicate-page/duplicatepage.php";i:2;s:37:"featured-banners/featured-banners.php";i:3;s:21:"our-faqs/our-faqs.php";i:4;s:27:"our-socials/our-socials.php";i:5;s:37:"post-types-order/post-types-order.php";i:6;s:24:"wordpress-seo/wp-seo.php";i:7;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'apollo', 'yes'),
(41, 'stylesheet', 'apollo', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:24:"wordpress-seo/wp-seo.php";s:14:"__return_false";}', 'no'),
(80, 'timezone_string', 'Africa/Johannesburg', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '8', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1690635160', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:10:"copy_posts";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:10:"copy_posts";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:39:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;s:10:"copy_posts";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:10:"copy_posts";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'en_ZA', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:9:{i:1675191161;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1675212761;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1675212768;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1675255961;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1675255968;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1675255973;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1675257373;a:2:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1675774361;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'nonce_key', '|Px5VoyW|{D-kEUA{#wB>``DSp|S<8+t/ZmjMBH{DH&gdDZjb#(.;KM*w9fHK]bt', 'no'),
(117, 'nonce_salt', '8wn|CS1:e6Xn,-MpIxY?o.:@&mrAC$x29~QZcc{gC)rPq7w<.-74x+QV$Y(/:y[&', 'no'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'recovery_keys', 'a:1:{s:22:"gNylr2zEPODd1u8rt2y3mK";a:2:{s:10:"hashed_key";s:34:"$P$BXADd0zjRb6rcb60R/b9DfX3XM61Xw.";s:10:"created_at";i:1675180404;}}', 'yes'),
(123, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:21:"HTTPS request failed.";}}', 'yes'),
(127, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1675083276;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(138, 'auth_key', 'yhc`e,LeKw2tKv/6:@} ,NvQ;}9u<O%G=|*L{qIN }fEG+SN/`/o;&.v+U[z~}:2', 'no'),
(139, 'auth_salt', 'y<]E_NC/^|%-;r:;4)S!(HUb,w;C<$GX@SQM{$NvNB0tAOy-JGMGb.{r`e.K;`3h', 'no'),
(140, 'logged_in_key', 'J4t?hQEV*J6V1F@RuXvAB#TcB..Mlu@iy$uq?bgY/Z0y67ZCEmslb;kb9)=t4$V2', 'no'),
(141, 'logged_in_salt', 'n5Le|-(`ATP,Wyf-3G@eTH,b=ojdV.!dN>0h$UnhMrz$?o>^{Gl@m@snvD{sg2)[', 'no'),
(148, 'can_compress_scripts', '1', 'no'),
(161, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(162, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(169, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:24:"gerhard@launchsite.co.za";s:7:"version";s:5:"6.1.1";s:9:"timestamp";i:1675083186;}', 'no'),
(173, 'finished_updating_comment_type', '1', 'yes'),
(174, 'recently_activated', 'a:3:{s:34:"advanced-custom-fields-pro/acf.php";i:1675181150;s:33:"duplicate-post/duplicate-post.php";i:1675177985;s:27:"our-banners/our-banners.php";i:1675176995;}', 'yes'),
(175, 'current_theme', 'Apollo Shutters', 'yes'),
(176, 'theme_mods_apollo', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(177, 'theme_switched', '', 'yes'),
(208, 'yoast_migrations_free', 'a:1:{s:7:"version";s:4:"20.0";}', 'yes'),
(209, 'wpseo', 'a:100:{s:8:"tracking";b:0;s:22:"license_server_version";b:0;s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:21:"post_type_made_public";s:29:"indexables_indexing_completed";b:1;s:13:"index_now_key";s:0:"";s:7:"version";s:4:"20.0";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:0;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:34:"inclusive_language_analysis_active";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:16:"enable_index_now";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1675084573;s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:36:"/%year%/%monthnum%/%day%/%postname%/";s:8:"home_url";s:30:"http://www.apollo-blinds.co.uk";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:0:"";s:12:"tag_base_url";s:0:"";s:21:"custom_taxonomy_slugs";a:0:{}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:3:{i:0;s:18:"siteRepresentation";i:1;s:14:"socialProfiles";i:2;s:19:"personalPreferences";}s:36:"dismiss_configuration_workout_notice";b:0;s:34:"dismiss_premium_deactivated_notice";b:0;s:26:"dismiss_old_premium_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:1;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:28:"wordproof_integration_active";b:0;s:29:"wordproof_integration_changed";b:0;s:18:"first_time_install";b:0;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";i:1675084573;s:18:"remove_feed_global";b:0;s:27:"remove_feed_global_comments";b:0;s:25:"remove_feed_post_comments";b:0;s:19:"remove_feed_authors";b:0;s:22:"remove_feed_categories";b:0;s:16:"remove_feed_tags";b:0;s:29:"remove_feed_custom_taxonomies";b:0;s:22:"remove_feed_post_types";b:0;s:18:"remove_feed_search";b:0;s:21:"remove_atom_rdf_feeds";b:0;s:17:"remove_shortlinks";b:0;s:21:"remove_rest_api_links";b:0;s:20:"remove_rsd_wlw_links";b:0;s:19:"remove_oembed_links";b:0;s:16:"remove_generator";b:0;s:20:"remove_emoji_scripts";b:0;s:24:"remove_powered_by_header";b:0;s:22:"remove_pingback_header";b:0;s:28:"clean_campaign_tracking_urls";b:0;s:16:"clean_permalinks";b:0;s:32:"clean_permalinks_extra_variables";s:0:"";s:14:"search_cleanup";b:0;s:20:"search_cleanup_emoji";b:0;s:23:"search_cleanup_patterns";b:0;s:22:"search_character_limit";i:50;s:20:"deny_search_crawling";b:0;s:21:"deny_wp_json_crawling";b:0;s:27:"redirect_search_pretty_urls";b:0;s:29:"least_readability_ignore_list";a:0:{}s:27:"least_seo_score_ignore_list";a:0:{}s:23:"most_linked_ignore_list";a:0:{}s:24:"least_linked_ignore_list";a:0:{}s:28:"indexables_page_reading_list";a:5:{i:0;b:0;i:1;b:0;i:2;b:0;i:3;b:0;i:4;b:0;}s:25:"indexables_overview_state";s:21:"dashboard-not-visited";s:28:"last_known_public_post_types";a:6:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:10:"attachment";i:3;s:16:"featured-banners";i:4;s:8:"our-faqs";i:5;s:11:"our-socials";}s:28:"last_known_public_taxonomies";a:3:{i:0;s:8:"category";i:1;s:8:"post_tag";i:2;s:11:"post_format";}}', 'yes'),
(210, 'wpseo_titles', 'a:110:{s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:66:"http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/Logo.png";s:12:"company_name";s:0:"";s:22:"company_alternate_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";i:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:12:"%%sitename%%";s:25:"open_graph_frontpage_desc";s:0:"";s:26:"open_graph_frontpage_image";s:0:"";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:23:"%%term_title%% Archives";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:26:"taxonomy-category-ptparent";i:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:23:"%%term_title%% Archives";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:26:"taxonomy-post_tag-ptparent";i:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:23:"%%term_title%% Archives";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:29:"taxonomy-post_format-ptparent";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:6;s:17:"company_logo_meta";a:10:{s:5:"width";i:354;s:6:"height";i:106;s:8:"filesize";i:5849;s:3:"url";s:66:"http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/Logo.png";s:4:"path";s:77:"/Applications/MAMP/htdocs/2022/apollo2023/wp-content/uploads/2023/01/Logo.png";s:4:"size";s:4:"full";s:2:"id";i:6;s:3:"alt";s:0:"";s:6:"pixels";i:37524;s:4:"type";s:9:"image/png";}s:16:"person_logo_meta";b:0;s:29:"open_graph_frontpage_image_id";i:0;}', 'yes'),
(211, 'wpseo_social', 'a:19:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:19:"og_default_image_id";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}}', 'yes'),
(257, 'acf_version', '6.0.7', 'yes'),
(825, 'duplicate_post_show_notice', '1', 'yes'),
(826, 'duplicate_post_copytitle', '1', 'yes'),
(827, 'duplicate_post_copydate', '0', 'yes'),
(828, 'duplicate_post_copystatus', '0', 'yes'),
(829, 'duplicate_post_copyslug', '0', 'yes'),
(830, 'duplicate_post_copyexcerpt', '1', 'yes'),
(831, 'duplicate_post_copycontent', '1', 'yes'),
(832, 'duplicate_post_copythumbnail', '1', 'yes'),
(833, 'duplicate_post_copytemplate', '1', 'yes'),
(834, 'duplicate_post_copyformat', '1', 'yes'),
(835, 'duplicate_post_copyauthor', '0', 'yes'),
(836, 'duplicate_post_copypassword', '0', 'yes'),
(837, 'duplicate_post_copyattachments', '0', 'yes'),
(838, 'duplicate_post_copychildren', '0', 'yes'),
(839, 'duplicate_post_copycomments', '0', 'yes'),
(840, 'duplicate_post_copymenuorder', '1', 'yes'),
(841, 'duplicate_post_taxonomies_blacklist', 'a:0:{}', 'yes'),
(842, 'duplicate_post_blacklist', '', 'yes'),
(843, 'duplicate_post_types_enabled', 'a:2:{i:0;s:4:"post";i:1;s:4:"page";}', 'yes'),
(844, 'duplicate_post_show_original_column', '0', 'yes'),
(845, 'duplicate_post_show_original_in_post_states', '0', 'yes'),
(846, 'duplicate_post_show_original_meta_box', '0', 'yes'),
(847, 'duplicate_post_show_link', 'a:3:{s:9:"new_draft";s:1:"1";s:5:"clone";s:1:"1";s:17:"rewrite_republish";s:1:"1";}', 'yes'),
(848, 'duplicate_post_show_link_in', 'a:4:{s:3:"row";s:1:"1";s:8:"adminbar";s:1:"1";s:9:"submitbox";s:1:"1";s:11:"bulkactions";s:1:"1";}', 'yes'),
(849, 'duplicate_post_version', '4.5', 'yes'),
(854, 'duplicate_page_options', 'a:4:{s:21:"duplicate_post_status";s:5:"draft";s:23:"duplicate_post_redirect";s:7:"to_list";s:21:"duplicate_post_suffix";s:0:"";s:21:"duplicate_post_editor";s:7:"classic";}', 'yes'),
(867, 'recovery_mode_email_last_sent', '1675180404', 'yes'),
(877, 'cpto_options', 'a:7:{s:23:"show_reorder_interfaces";a:4:{s:4:"post";s:4:"show";s:10:"attachment";s:4:"show";s:8:"wp_block";s:4:"show";s:13:"wp_navigation";s:4:"show";}s:8:"autosort";i:1;s:9:"adminsort";i:1;s:18:"use_query_ASC_DESC";s:0:"";s:17:"archive_drag_drop";i:1;s:10:"capability";s:14:"manage_options";s:21:"navigation_sort_apply";i:1;}', 'yes'),
(878, 'CPT_configured', 'TRUE', 'yes'),
(1015, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1675188437;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1675084392:1'),
(4, 6, '_wp_attached_file', '2023/01/Logo.png'),
(5, 6, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:354;s:6:"height";i:106;s:4:"file";s:16:"2023/01/Logo.png";s:8:"filesize";i:5849;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:15:"Logo-300x90.png";s:5:"width";i:300;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19620;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"Logo-150x106.png";s:5:"width";i:150;s:6:"height";i:106;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8129;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(6, 7, '_edit_lock', '1675084803:1'),
(7, 8, '_edit_last', '1'),
(8, 8, '_edit_lock', '1675089192:1'),
(9, 8, '_wp_page_template', 'page-home.php'),
(10, 8, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(11, 8, '_yoast_wpseo_wordproof_timestamp', ''),
(12, 13, '_edit_last', '1'),
(13, 13, '_edit_lock', '1675179232:1'),
(14, 13, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(15, 13, '_yoast_wpseo_wordproof_timestamp', ''),
(16, 13, 'faqs_name', 'Lorem ipsum dolor sit amet 1?'),
(17, 13, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(18, 17, '_edit_last', '1'),
(19, 17, '_edit_lock', '1675178016:1'),
(20, 17, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(21, 17, '_yoast_wpseo_wordproof_timestamp', ''),
(22, 17, 'faqs_name', 'Lorem ipsum dolor sit amet 2?'),
(23, 17, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(24, 18, '_edit_last', '1'),
(25, 18, '_edit_lock', '1675178015:1'),
(26, 18, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(27, 18, '_yoast_wpseo_wordproof_timestamp', ''),
(28, 18, 'faqs_name', 'Lorem ipsum dolor sit amet 3?'),
(29, 18, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(30, 19, '_edit_last', '1'),
(31, 19, '_edit_lock', '1675178015:1'),
(32, 19, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(33, 19, '_yoast_wpseo_wordproof_timestamp', ''),
(34, 19, 'faqs_name', 'Lorem ipsum dolor sit amet 4?'),
(35, 19, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(36, 20, '_edit_last', '1'),
(37, 20, '_edit_lock', '1675178014:1'),
(38, 20, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(39, 20, '_yoast_wpseo_wordproof_timestamp', ''),
(40, 20, 'faqs_name', 'Lorem ipsum dolor sit amet 5?'),
(41, 20, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(42, 21, '_edit_last', '1'),
(43, 21, '_edit_lock', '1675178013:1'),
(44, 21, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(45, 21, '_yoast_wpseo_wordproof_timestamp', ''),
(46, 21, 'faqs_name', 'Lorem ipsum dolor sit amet 6?'),
(47, 21, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(48, 22, '_edit_last', '1'),
(49, 22, '_edit_lock', '1675178013:1'),
(50, 22, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(51, 22, '_yoast_wpseo_wordproof_timestamp', ''),
(52, 22, 'faqs_name', 'Lorem ipsum dolor sit amet 7?'),
(53, 22, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(54, 23, '_edit_last', '1'),
(55, 23, '_edit_lock', '1675178012:1'),
(56, 23, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(57, 23, '_yoast_wpseo_wordproof_timestamp', ''),
(58, 23, 'faqs_name', 'Lorem ipsum dolor sit amet 8?'),
(59, 23, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(60, 24, '_edit_last', '1'),
(61, 24, '_edit_lock', '1675178011:1'),
(62, 24, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(63, 24, '_yoast_wpseo_wordproof_timestamp', ''),
(64, 24, 'faqs_name', 'Lorem ipsum dolor sit amet 9?'),
(65, 24, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(66, 25, '_edit_last', '1'),
(67, 25, '_edit_lock', '1675177754:1'),
(68, 25, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(69, 25, '_yoast_wpseo_wordproof_timestamp', ''),
(70, 25, 'faqs_name', 'Lorem ipsum dolor sit amet ?'),
(71, 25, 'faqs_content', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(72, 25, '_wp_trash_meta_status', 'draft'),
(73, 25, '_wp_trash_meta_time', '1675178092'),
(74, 25, '_wp_desired_post_slug', ''),
(75, 36, '_edit_last', '1'),
(76, 36, '_edit_lock', '1675183191:1'),
(77, 36, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(78, 36, '_yoast_wpseo_wordproof_timestamp', ''),
(79, 36, 'banner_overview', 'Lorem ipsum dolor sit amet, consectetur Banner 1'),
(80, 38, '_wp_attached_file', '2023/01/top_banner.png'),
(81, 38, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1367;s:6:"height";i:566;s:4:"file";s:22:"2023/01/top_banner.png";s:8:"filesize";i:354203;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:22:"top_banner-300x124.png";s:5:"width";i:300;s:6:"height";i:124;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:70250;}s:5:"large";a:5:{s:4:"file";s:23:"top_banner-1024x424.png";s:5:"width";i:1024;s:6:"height";i:424;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:686124;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"top_banner-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:39978;}s:12:"medium_large";a:5:{s:4:"file";s:22:"top_banner-768x318.png";s:5:"width";i:768;s:6:"height";i:318;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:400719;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(82, 36, '_thumbnail_id', '38'),
(83, 41, '_edit_last', '1'),
(84, 41, '_edit_lock', '1675182273:1'),
(85, 41, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(86, 41, '_yoast_wpseo_wordproof_timestamp', ''),
(87, 41, 'banner_overview', 'Lorem ipsum dolor sit amet, consectetur Banner 2'),
(88, 41, '_thumbnail_id', '73'),
(89, 45, '_edit_last', '1'),
(90, 45, '_edit_lock', '1675182285:1'),
(91, 45, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(92, 45, '_yoast_wpseo_wordproof_timestamp', ''),
(93, 45, 'banner_overview', 'Lorem ipsum dolor sit amet, consectetur Banner 3'),
(94, 45, '_thumbnail_id', '72'),
(117, 55, '_edit_last', '1'),
(118, 55, '_edit_lock', '1675180951:1'),
(119, 55, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(120, 55, '_yoast_wpseo_wordproof_timestamp', ''),
(121, 55, 'social_network', 'facebook'),
(122, 55, 'social_network_url', '#') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(123, 58, '_edit_last', '1'),
(124, 58, '_edit_lock', '1675180969:1'),
(125, 58, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(126, 58, '_yoast_wpseo_wordproof_timestamp', ''),
(127, 58, 'social_network', 'pinterest'),
(128, 58, 'social_network_url', '#'),
(129, 60, '_edit_last', '1'),
(130, 60, '_edit_lock', '1675180980:1'),
(131, 60, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(132, 60, '_yoast_wpseo_wordproof_timestamp', ''),
(133, 60, 'social_network', 'twitter'),
(134, 60, 'social_network_url', '#'),
(135, 62, '_edit_last', '1'),
(136, 62, '_edit_lock', '1675180993:1'),
(137, 62, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(138, 62, '_yoast_wpseo_wordproof_timestamp', ''),
(139, 62, 'social_network', 'instagram'),
(140, 62, 'social_network_url', '#'),
(141, 64, '_edit_last', '1'),
(142, 64, '_edit_lock', '1675181106:1'),
(143, 64, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(144, 64, '_yoast_wpseo_wordproof_timestamp', ''),
(145, 64, 'social_network', 'linkedin'),
(146, 64, 'social_network_url', '#'),
(147, 66, '_edit_last', '1'),
(148, 66, '_edit_lock', '1675181216:1'),
(149, 66, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(150, 66, '_yoast_wpseo_wordproof_timestamp', ''),
(151, 66, 'social_network', 'youtube'),
(152, 66, 'social_network_url', '#'),
(153, 69, '_edit_last', '1'),
(154, 69, '_edit_lock', '1675182848:1'),
(155, 69, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(156, 69, '_yoast_wpseo_wordproof_timestamp', ''),
(157, 69, 'banner_overview', 'Lorem ipsum dolor sit amet, consectetur Banner 4'),
(158, 69, '_thumbnail_id', '71'),
(159, 71, '_wp_attached_file', '2023/01/home-office-blinds.jpg'),
(160, 71, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1080;s:6:"height";i:550;s:4:"file";s:30:"2023/01/home-office-blinds.jpg";s:8:"filesize";i:65668;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:30:"home-office-blinds-300x153.jpg";s:5:"width";i:300;s:6:"height";i:153;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13476;}s:5:"large";a:5:{s:4:"file";s:31:"home-office-blinds-1024x521.jpg";s:5:"width";i:1024;s:6:"height";i:521;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:84781;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"home-office-blinds-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7138;}s:12:"medium_large";a:5:{s:4:"file";s:30:"home-office-blinds-768x391.jpg";s:5:"width";i:768;s:6:"height";i:391;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:55658;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(161, 72, '_wp_attached_file', '2023/01/home-office-film-noir-venetian-blinds.jpg'),
(162, 72, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1080;s:6:"height";i:550;s:4:"file";s:49:"2023/01/home-office-film-noir-venetian-blinds.jpg";s:8:"filesize";i:48637;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:49:"home-office-film-noir-venetian-blinds-300x153.jpg";s:5:"width";i:300;s:6:"height";i:153;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9738;}s:5:"large";a:5:{s:4:"file";s:50:"home-office-film-noir-venetian-blinds-1024x521.jpg";s:5:"width";i:1024;s:6:"height";i:521;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:65940;}s:9:"thumbnail";a:5:{s:4:"file";s:49:"home-office-film-noir-venetian-blinds-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6059;}s:12:"medium_large";a:5:{s:4:"file";s:49:"home-office-film-noir-venetian-blinds-768x391.jpg";s:5:"width";i:768;s:6:"height";i:391;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:42392;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(163, 73, '_wp_attached_file', '2023/01/home-office-vertical-blinds.jpg'),
(164, 73, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1080;s:6:"height";i:550;s:4:"file";s:39:"2023/01/home-office-vertical-blinds.jpg";s:8:"filesize";i:56646;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:39:"home-office-vertical-blinds-300x153.jpg";s:5:"width";i:300;s:6:"height";i:153;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9807;}s:5:"large";a:5:{s:4:"file";s:40:"home-office-vertical-blinds-1024x521.jpg";s:5:"width";i:1024;s:6:"height";i:521;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:70546;}s:9:"thumbnail";a:5:{s:4:"file";s:39:"home-office-vertical-blinds-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6796;}s:12:"medium_large";a:5:{s:4:"file";s:39:"home-office-vertical-blinds-768x391.jpg";s:5:"width";i:768;s:6:"height";i:391;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44168;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(165, 74, '_wp_attached_file', '2023/01/home-office-wooden-blinds.jpg'),
(166, 74, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1080;s:6:"height";i:550;s:4:"file";s:37:"2023/01/home-office-wooden-blinds.jpg";s:8:"filesize";i:63924;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:37:"home-office-wooden-blinds-300x153.jpg";s:5:"width";i:300;s:6:"height";i:153;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13039;}s:5:"large";a:5:{s:4:"file";s:38:"home-office-wooden-blinds-1024x521.jpg";s:5:"width";i:1024;s:6:"height";i:521;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:82107;}s:9:"thumbnail";a:5:{s:4:"file";s:37:"home-office-wooden-blinds-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7454;}s:12:"medium_large";a:5:{s:4:"file";s:37:"home-office-wooden-blinds-768x391.jpg";s:5:"width";i:768;s:6:"height";i:391;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:54357;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-01-30 14:52:41', '2023-01-30 12:52:41', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2023-01-30 14:52:41', '2023-01-30 12:52:41', '', 0, 'http://www.apollo-blinds.co.uk/?p=1', 0, 'post', '', 1),
(2, 1, '2023-01-30 14:52:41', '2023-01-30 12:52:41', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://www.apollo-blinds.co.uk/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2023-01-30 14:52:41', '2023-01-30 12:52:41', '', 0, 'http://www.apollo-blinds.co.uk/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-01-30 14:52:41', '2023-01-30 12:52:41', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://www.apollo-blinds.co.uk.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymised string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognise and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2023-01-30 14:52:41', '2023-01-30 12:52:41', '', 0, 'http://www.apollo-blinds.co.uk/?page_id=3', 0, 'page', '', 0),
(4, 1, '2023-01-30 14:52:53', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-01-30 14:52:53', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?p=4', 0, 'post', '', 0),
(5, 1, '2023-01-30 15:15:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-01-30 15:15:32', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?page_id=5', 0, 'page', '', 0),
(6, 1, '2023-01-30 15:16:35', '2023-01-30 13:16:35', '', 'Logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2023-01-30 15:16:35', '2023-01-30 13:16:35', '', 0, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/Logo.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2023-01-30 15:22:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-01-30 15:22:25', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?page_id=7', 0, 'page', '', 0),
(8, 1, '2023-01-30 15:31:09', '2023-01-30 13:31:09', '', 'Home Page', '', 'publish', 'closed', 'closed', '', 'home-page', '', '', '2023-01-30 16:35:35', '2023-01-30 14:35:35', '', 0, 'http://www.apollo-blinds.co.uk/?page_id=8', 0, 'page', '', 0),
(10, 1, '2023-01-31 16:55:40', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-01-31 16:55:40', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=featured-banners&p=10', 0, 'featured-banners', '', 0),
(11, 1, '2023-01-31 16:56:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-01-31 16:56:12', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=featured-banners&p=11', 0, 'featured-banners', '', 0),
(12, 1, '2023-01-31 17:05:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-01-31 17:05:14', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&p=12', 0, 'our-faqs', '', 0),
(13, 1, '2023-01-31 17:06:09', '2023-01-31 15:06:09', '', 'Lorem ipsum dolor sit amet 1', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet', '', '', '2023-01-31 17:15:26', '2023-01-31 15:15:26', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=13', 0, 'our-faqs', '', 0),
(17, 1, '2023-01-31 17:13:52', '2023-01-31 15:13:52', '', 'Lorem ipsum dolor sit amet 2', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-2', '', '', '2023-01-31 17:15:21', '2023-01-31 15:15:21', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=17', 1, 'our-faqs', '', 0),
(18, 1, '2023-01-31 17:13:54', '2023-01-31 15:13:54', '', 'Lorem ipsum dolor sit amet 3', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-3', '', '', '2023-01-31 17:15:31', '2023-01-31 15:15:31', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=18', 2, 'our-faqs', '', 0),
(19, 1, '2023-01-31 17:13:56', '2023-01-31 15:13:56', '', 'Lorem ipsum dolor sit amet 4', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-4', '', '', '2023-01-31 17:15:34', '2023-01-31 15:15:34', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=19', 3, 'our-faqs', '', 0),
(20, 1, '2023-01-31 17:13:58', '2023-01-31 15:13:58', '', 'Lorem ipsum dolor sit amet 5', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-5', '', '', '2023-01-31 17:15:38', '2023-01-31 15:15:38', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=20', 4, 'our-faqs', '', 0),
(21, 1, '2023-01-31 17:13:59', '2023-01-31 15:13:59', '', 'Lorem ipsum dolor sit amet 6', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-6', '', '', '2023-01-31 17:15:41', '2023-01-31 15:15:41', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=21', 5, 'our-faqs', '', 0),
(22, 1, '2023-01-31 17:14:01', '2023-01-31 15:14:01', '', 'Lorem ipsum dolor sit amet 7', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-7', '', '', '2023-01-31 17:15:46', '2023-01-31 15:15:46', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=22', 6, 'our-faqs', '', 0),
(23, 1, '2023-01-31 17:14:03', '2023-01-31 15:14:03', '', 'Lorem ipsum dolor sit amet 8', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-8', '', '', '2023-01-31 17:15:50', '2023-01-31 15:15:50', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=23', 7, 'our-faqs', '', 0),
(24, 1, '2023-01-31 17:14:04', '2023-01-31 15:14:04', '', 'Lorem ipsum dolor sit amet 9', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-9', '', '', '2023-01-31 17:15:54', '2023-01-31 15:15:54', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=24', 8, 'our-faqs', '', 0),
(25, 1, '2023-01-31 17:14:52', '2023-01-31 15:14:52', '', 'Lorem ipsum dolor sit amet', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2023-01-31 17:14:52', '2023-01-31 15:14:52', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&#038;p=25', 0, 'our-faqs', '', 0),
(36, 1, '2023-01-31 17:21:57', '2023-01-31 15:21:57', '', 'Banner 1', '', 'publish', 'closed', 'closed', '', 'banner-1', '', '', '2023-01-31 18:36:41', '2023-01-31 16:36:41', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=featured-banners&#038;p=36', 0, 'featured-banners', '', 0),
(38, 1, '2023-01-31 17:24:16', '2023-01-31 15:24:16', '', 'top_banner', '', 'inherit', 'open', 'closed', '', 'top_banner', '', '', '2023-01-31 17:24:16', '2023-01-31 15:24:16', '', 36, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/top_banner.png', 0, 'attachment', 'image/png', 0),
(41, 1, '2023-01-31 17:24:54', '2023-01-31 15:24:54', '', 'Banner 2', '', 'publish', 'closed', 'closed', '', 'banner-2', '', '', '2023-01-31 18:26:56', '2023-01-31 16:26:56', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=featured-banners&#038;p=41', 1, 'featured-banners', '', 0),
(45, 1, '2023-01-31 17:25:07', '2023-01-31 15:25:07', '', 'Banner 3', '', 'publish', 'closed', 'closed', '', 'banner-3', '', '', '2023-01-31 18:27:09', '2023-01-31 16:27:09', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=featured-banners&#038;p=45', 2, 'featured-banners', '', 0),
(47, 1, '2023-01-31 17:26:53', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-01-31 17:26:53', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=acf-field-group&p=47', 0, 'acf-field-group', '', 0),
(51, 1, '2023-01-31 17:33:22', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-01-31 17:33:22', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?p=51', 0, 'post', '', 0),
(55, 1, '2023-01-31 18:01:55', '2023-01-31 16:01:55', '', 'Facebook', '', 'publish', 'closed', 'closed', '', 'facebook', '', '', '2023-01-31 18:04:52', '2023-01-31 16:04:52', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-socials&#038;p=55', 0, 'our-socials', '', 0),
(58, 1, '2023-01-31 18:05:10', '2023-01-31 16:05:10', '', 'Pinterest', '', 'publish', 'closed', 'closed', '', 'pinterest', '', '', '2023-01-31 18:05:10', '2023-01-31 16:05:10', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-socials&#038;p=58', 1, 'our-socials', '', 0),
(60, 1, '2023-01-31 18:05:23', '2023-01-31 16:05:23', '', 'Twitter', '', 'publish', 'closed', 'closed', '', 'twitter', '', '', '2023-01-31 18:05:23', '2023-01-31 16:05:23', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-socials&#038;p=60', 2, 'our-socials', '', 0),
(62, 1, '2023-01-31 18:05:35', '2023-01-31 16:05:35', '', 'Instagram', '', 'publish', 'closed', 'closed', '', 'instagram', '', '', '2023-01-31 18:05:35', '2023-01-31 16:05:35', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-socials&#038;p=62', 3, 'our-socials', '', 0),
(64, 1, '2023-01-31 18:07:27', '2023-01-31 16:07:27', '', 'LinkedIn', '', 'publish', 'closed', 'closed', '', 'linkedin', '', '', '2023-01-31 18:07:27', '2023-01-31 16:07:27', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-socials&#038;p=64', 0, 'our-socials', '', 0),
(66, 1, '2023-01-31 18:07:41', '2023-01-31 16:07:41', '', 'YouTube', '', 'publish', 'closed', 'closed', '', 'youtube', '', '', '2023-01-31 18:07:41', '2023-01-31 16:07:41', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-socials&#038;p=66', 0, 'our-socials', '', 0),
(68, 1, '2023-01-31 18:07:48', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-01-31 18:07:48', '0000-00-00 00:00:00', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=our-socials&p=68', 0, 'our-socials', '', 0),
(69, 1, '2023-01-31 18:21:37', '2023-01-31 16:21:37', '', 'Banner 4', '', 'publish', 'closed', 'closed', '', 'banner-4', '', '', '2023-01-31 18:27:22', '2023-01-31 16:27:22', '', 0, 'http://www.apollo-blinds.co.uk/?post_type=featured-banners&#038;p=69', 3, 'featured-banners', '', 0),
(71, 1, '2023-01-31 18:26:33', '2023-01-31 16:26:33', '', 'home-office-blinds', '', 'inherit', 'open', 'closed', '', 'home-office-blinds', '', '', '2023-01-31 18:26:33', '2023-01-31 16:26:33', '', 36, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-blinds.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2023-01-31 18:26:33', '2023-01-31 16:26:33', '', 'home-office-film-noir-venetian-blinds', '', 'inherit', 'open', 'closed', '', 'home-office-film-noir-venetian-blinds', '', '', '2023-01-31 18:26:33', '2023-01-31 16:26:33', '', 36, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-film-noir-venetian-blinds.jpg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2023-01-31 18:26:34', '2023-01-31 16:26:34', '', 'home-office-vertical-blinds', '', 'inherit', 'open', 'closed', '', 'home-office-vertical-blinds', '', '', '2023-01-31 18:26:34', '2023-01-31 16:26:34', '', 36, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-vertical-blinds.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2023-01-31 18:26:34', '2023-01-31 16:26:34', '', 'home-office-wooden-blinds', '', 'inherit', 'open', 'closed', '', 'home-office-wooden-blinds', '', '', '2023-01-31 18:26:34', '2023-01-31 16:26:34', '', 36, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-wooden-blinds.jpg', 0, 'attachment', 'image/jpeg', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorised', 'uncategorised', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"8f4ad419cdc4b54dc67c17d4039e2dff3526e83ad2a86e08e112d0207a687e1d";a:4:{s:10:"expiration";i:1676292768;s:2:"ip";s:3:"::1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36";s:5:"login";i:1675083168;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'wp_persisted_preferences', 'a:2:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:2:{i:0;s:11:"post-status";i:1;s:24:"yoast-seo/document-panel";}}s:9:"_modified";s:24:"2023-01-30T13:22:26.320Z";}'),
(20, 1, 'wp_user-settings', 'libraryContent=browse&mfold=o'),
(21, 1, 'wp_user-settings-time', '1675182395'),
(22, 1, '_yoast_settings_introduction', 'a:2:{s:23:"wistia_embed_permission";b:0;s:4:"show";b:0;}'),
(23, 1, 'wp_yoast_notifications', 'a:3:{i:0;a:2:{s:7:"message";s:484:"<p><strong>Huge SEO Issue: You&#039;re blocking access to robots.</strong> If you want search engines to show this site in their results, you must <a href="http://www.apollo-blinds.co.uk/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility. <button type="button" id="robotsmessage-dismiss-button" class="button-link hide-if-no-js" data-nonce="44fb51a43d">I don&#039;t want this site to show in the search results.</button></p>";s:7:"options";a:10:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-search-engines-discouraged";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:5:"admin";s:9:"user_pass";s:34:"$P$BxOxckxsVulh66zNUnvhLKgr0RY.rE/";s:13:"user_nicename";s:5:"admin";s:10:"user_email";s:24:"gerhard@launchsite.co.za";s:8:"user_url";s:30:"http://www.apollo-blinds.co.uk";s:15:"user_registered";s:19:"2023-01-30 12:52:41";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:5:"admin";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}i:1;a:2:{s:7:"message";s:223:"It looks like you&#039;ve added a new type of content to your website. We recommend that you review your <a href="http://www.apollo-blinds.co.uk/wp-admin/admin.php?page=wpseo_page_settings">Settings</a> under Content types.";s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:22:"post-types-made-public";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:5:"admin";s:9:"user_pass";s:34:"$P$BxOxckxsVulh66zNUnvhLKgr0RY.rE/";s:13:"user_nicename";s:5:"admin";s:10:"user_email";s:24:"gerhard@launchsite.co.za";s:8:"user_url";s:30:"http://www.apollo-blinds.co.uk";s:15:"user_registered";s:19:"2023-01-30 12:52:41";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:5:"admin";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}i:2;a:2:{s:7:"message";s:224:"It looks like you&#039;ve added a new taxonomy to your website. We recommend that you review your <a href="http://www.apollo-blinds.co.uk/wp-admin/admin.php?page=wpseo_page_settings">Settings</a> under Categories &amp; tags.";s:7:"options";a:10:{s:4:"type";s:7:"warning";s:2:"id";s:22:"taxonomies-made-public";s:4:"user";O:7:"WP_User":8:{s:4:"data";O:8:"stdClass":10:{s:2:"ID";s:1:"1";s:10:"user_login";s:5:"admin";s:9:"user_pass";s:34:"$P$BxOxckxsVulh66zNUnvhLKgr0RY.rE/";s:13:"user_nicename";s:5:"admin";s:10:"user_email";s:24:"gerhard@launchsite.co.za";s:8:"user_url";s:30:"http://www.apollo-blinds.co.uk";s:15:"user_registered";s:19:"2023-01-30 12:52:41";s:19:"user_activation_key";s:0:"";s:11:"user_status";s:1:"0";s:12:"display_name";s:5:"admin";}s:2:"ID";i:1;s:4:"caps";a:1:{s:13:"administrator";b:1;}s:7:"cap_key";s:15:"wp_capabilities";s:5:"roles";a:1:{i:0;s:13:"administrator";}s:7:"allcaps";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:13:"administrator";b:1;}s:6:"filter";N;s:16:"\0WP_User\0site_id";i:1;}s:5:"nonce";N;s:8:"priority";d:0.8;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";s:14:"yoast_branding";b:0;}}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BxOxckxsVulh66zNUnvhLKgr0RY.rE/', 'admin', 'gerhard@launchsite.co.za', 'http://www.apollo-blinds.co.uk', '2023-01-30 12:52:41', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable`
#

DROP TABLE IF EXISTS `wp_yoast_indexable`;


#
# Table structure of table `wp_yoast_indexable`
#

CREATE TABLE `wp_yoast_indexable` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `permalink` longtext COLLATE utf8_unicode_ci,
  `permalink_hash` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci,
  `description` mediumtext COLLATE utf8_unicode_ci,
  `breadcrumb_title` text COLLATE utf8_unicode_ci,
  `post_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT '0',
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(11) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8_unicode_ci,
  `primary_focus_keyword` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(3) DEFAULT NULL,
  `readability_score` int(3) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT '0',
  `is_robots_noindex` tinyint(1) DEFAULT '0',
  `is_robots_nofollow` tinyint(1) DEFAULT '0',
  `is_robots_noarchive` tinyint(1) DEFAULT '0',
  `is_robots_noimageindex` tinyint(1) DEFAULT '0',
  `is_robots_nosnippet` tinyint(1) DEFAULT '0',
  `twitter_title` text COLLATE utf8_unicode_ci,
  `twitter_image` longtext COLLATE utf8_unicode_ci,
  `twitter_description` longtext COLLATE utf8_unicode_ci,
  `twitter_image_id` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8_unicode_ci,
  `open_graph_title` text COLLATE utf8_unicode_ci,
  `open_graph_description` longtext COLLATE utf8_unicode_ci,
  `open_graph_image` longtext COLLATE utf8_unicode_ci,
  `open_graph_image_id` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8_unicode_ci,
  `open_graph_image_meta` mediumtext COLLATE utf8_unicode_ci,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  `language` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT '0',
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT '1',
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  KEY `object_id_and_type` (`object_id`,`object_type`),
  KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_yoast_indexable`
#
INSERT INTO `wp_yoast_indexable` ( `id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(1, 'http://www.apollo-blinds.co.uk/?page_id=3', '48:f3ed8319e442b9830096b311ef8776fc', 3, 'post', 'page', 1, 0, NULL, NULL, 'Privacy Policy', 'draft', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 14:55:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 12:52:41', '2023-01-30 12:52:41'),
(2, 'http://www.apollo-blinds.co.uk/author/admin/', '51:4ef84df3ca91d82037d2def7f7519707', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, 'https://2.gravatar.com/avatar/e416819009b0d218b841ea5fe1b919b5?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://2.gravatar.com/avatar/e416819009b0d218b841ea5fe1b919b5?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 16:36:41', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-31 16:36:41', '2023-01-30 12:52:41'),
(3, 'http://www.apollo-blinds.co.uk/sample-page/', '50:a2ca195a00de4d1883ea2afe6593a81f', 2, 'post', 'page', 1, 0, NULL, NULL, 'Sample Page', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 14:55:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 12:52:41', '2023-01-30 12:52:41'),
(4, 'http://www.apollo-blinds.co.uk/2023/01/30/hello-world/', '61:ec87662d26251daa96516c828e242afc', 1, 'post', 'post', 1, 0, NULL, NULL, 'Hello world!', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 14:55:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 12:52:41', '2023-01-30 12:52:41'),
(5, 'http://www.apollo-blinds.co.uk/category/uncategorised/', '61:5c8e97afec40c39f909002536a235307', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'Uncategorised', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 14:55:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 12:52:41', '2023-01-30 12:52:41'),
(6, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 13:19:56', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(7, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 14:55:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(8, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 14:55:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(9, 'http://www.apollo-blinds.co.uk/', '38:3205cedb9a73bc5b1aa5e1e2522a134d', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%page%% %%sep%% %%sitedesc%%', 'Just another WordPress site', 'Home', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%%', '', '', '0', NULL, NULL, NULL, NULL, NULL, '2023-01-30 13:16:13', '2023-01-31 16:36:41', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-31 16:36:41', '2023-01-30 12:52:41'),
(10, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/Logo.png', '73:c5f208f294b33cb5a382f26e9a5d7b26', 6, 'post', 'attachment', 1, 0, NULL, NULL, 'Logo', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/Logo.png', NULL, '6', 'attachment-image', NULL, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/Logo.png', '6', 'attachment-image', '{"width":354,"height":106,"filesize":5849,"url":"http:\\/\\/www.apollo-blinds.co.uk\\/wp-content\\/uploads\\/2023\\/01\\/Logo.png","path":"\\/Applications\\/MAMP\\/htdocs\\/2022\\/apollo2023\\/wp-content\\/uploads\\/2023\\/01\\/Logo.png","size":"full","id":6,"alt":"","pixels":37524,"type":"image\\/png"}', NULL, NULL, NULL, '2023-01-30 13:16:35', '2023-01-31 14:55:27', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 13:16:35', '2023-01-30 13:16:35'),
(11, 'http://www.apollo-blinds.co.uk/', '38:3205cedb9a73bc5b1aa5e1e2522a134d', 8, 'post', 'page', 1, 0, NULL, NULL, 'Home Page', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-30 13:31:08', '2023-01-31 13:16:45', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-30 14:35:35', '2023-01-30 13:31:09'),
(12, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet/', '74:30ac457255863c6842b70a0e1b46c358', 13, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 1', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:06:04', '2023-01-31 15:15:26', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:26', '2023-01-31 15:06:09'),
(13, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-2/', '76:ea6f50465f53dae88b000d184d524ac2', 17, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 2', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:13:52', '2023-01-31 15:15:21', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:21', '2023-01-31 15:13:52'),
(14, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-3/', '76:995b1d8448d570b78aafa9bd41767a7e', 18, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 3', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:13:54', '2023-01-31 15:15:31', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:31', '2023-01-31 15:13:54'),
(15, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-4/', '76:657f4c507f22df6478632ace1af68370', 19, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 4', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:13:56', '2023-01-31 15:15:34', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:34', '2023-01-31 15:13:56'),
(16, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-5/', '76:2fcb9a4ca8d4eaec8edeb17ede1a7cf4', 20, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 5', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:13:58', '2023-01-31 15:15:38', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:38', '2023-01-31 15:13:58'),
(17, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-6/', '76:8162e4cc03374ca4db631fe069480d44', 21, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 6', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:13:59', '2023-01-31 15:15:41', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:41', '2023-01-31 15:13:59'),
(18, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-7/', '76:b39d098ddf69dd327446d61d220048ae', 22, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 7', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:14:01', '2023-01-31 15:15:46', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:46', '2023-01-31 15:14:01'),
(19, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-8/', '76:8240f230b943f178dac6fce23db8dcd3', 23, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 8', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:14:03', '2023-01-31 15:15:50', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:50', '2023-01-31 15:14:03'),
(20, 'http://www.apollo-blinds.co.uk/our-faqs/lorem-ipsum-dolor-sit-amet-9/', '76:8464e15fd17632b2effbb362aa5b395d', 24, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet 9', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 15:14:04', '2023-01-31 15:15:54', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:15:54', '2023-01-31 15:14:04'),
(21, 'http://www.apollo-blinds.co.uk/?post_type=our-faqs&p=25', '62:d50c4c625f2f34b338198089816fd7f2', 25, 'post', 'our-faqs', 1, 0, NULL, NULL, 'Lorem ipsum dolor sit amet', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-31 15:14:06', '2023-01-31 15:14:52', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 15:14:52', '2023-01-31 15:14:52'),
(22, 'http://www.apollo-blinds.co.uk/featured-banners/banner-1/', '64:00fbaa016e6d0b2bd7f6c8fad50575b8', 36, 'post', 'featured-banners', 1, 0, NULL, NULL, 'Banner 1', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/top_banner.png', NULL, '38', 'featured-image', NULL, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/top_banner.png', '38', 'featured-image', '{"width":1367,"height":566,"filesize":354203,"url":"http:\\/\\/www.apollo-blinds.co.uk\\/wp-content\\/uploads\\/2023\\/01\\/top_banner.png","path":"\\/Applications\\/MAMP\\/htdocs\\/2022\\/apollo2023\\/wp-content\\/uploads\\/2023\\/01\\/top_banner.png","size":"full","id":38,"alt":"","pixels":773722,"type":"image\\/png"}', 0, NULL, NULL, '2023-01-31 15:21:56', '2023-01-31 16:36:41', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:36:41', '2023-01-31 15:21:57'),
(23, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/top_banner.png', '79:ac8478a9f8ae22df982d1608ac2323a0', 38, 'post', 'attachment', 1, 36, NULL, NULL, 'top_banner', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/top_banner.png', NULL, '38', 'attachment-image', NULL, NULL, NULL, '38', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-31 15:24:16', '2023-01-31 15:25:35', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2023-01-31 15:24:16', '2023-01-31 15:24:16'),
(24, 'http://www.apollo-blinds.co.uk/featured-banners/banner-2/', '64:55e52f10094627481dc0e02471ee3f65', 41, 'post', 'featured-banners', 1, 0, NULL, NULL, 'Banner 2', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-vertical-blinds.jpg', NULL, '73', 'featured-image', NULL, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-vertical-blinds.jpg', '73', 'featured-image', '{"width":1080,"height":550,"filesize":56646,"url":"http:\\/\\/www.apollo-blinds.co.uk\\/wp-content\\/uploads\\/2023\\/01\\/home-office-vertical-blinds.jpg","path":"\\/Applications\\/MAMP\\/htdocs\\/2022\\/apollo2023\\/wp-content\\/uploads\\/2023\\/01\\/home-office-vertical-blinds.jpg","size":"full","id":73,"alt":"","pixels":594000,"type":"image\\/jpeg"}', 0, NULL, NULL, '2023-01-31 15:24:54', '2023-01-31 16:26:56', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:26:56', '2023-01-31 15:24:54'),
(25, 'http://www.apollo-blinds.co.uk/featured-banners/banner-3/', '64:ff1e9e41a8553667001187ba8493218d', 45, 'post', 'featured-banners', 1, 0, NULL, NULL, 'Banner 3', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-film-noir-venetian-blinds.jpg', NULL, '72', 'featured-image', NULL, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-film-noir-venetian-blinds.jpg', '72', 'featured-image', '{"width":1080,"height":550,"filesize":48637,"url":"http:\\/\\/www.apollo-blinds.co.uk\\/wp-content\\/uploads\\/2023\\/01\\/home-office-film-noir-venetian-blinds.jpg","path":"\\/Applications\\/MAMP\\/htdocs\\/2022\\/apollo2023\\/wp-content\\/uploads\\/2023\\/01\\/home-office-film-noir-venetian-blinds.jpg","size":"full","id":72,"alt":"","pixels":594000,"type":"image\\/jpeg"}', 0, NULL, NULL, '2023-01-31 15:25:07', '2023-01-31 16:27:09', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:27:09', '2023-01-31 15:25:07'),
(27, 'http://www.apollo-blinds.co.uk/our-socials/facebook/', '59:706b98bbc9cc9a021126638e83b9a325', 55, 'post', 'our-socials', 1, 0, NULL, NULL, 'Facebook', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 16:01:51', '2023-01-31 16:04:52', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:04:52', '2023-01-31 16:01:55'),
(28, 'http://www.apollo-blinds.co.uk/our-socials/pinterest/', '60:976f29a9f59f955317abd1fb835013cb', 58, 'post', 'our-socials', 1, 0, NULL, NULL, 'Pinterest', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 16:05:06', '2023-01-31 16:05:10', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:05:10', '2023-01-31 16:05:10'),
(29, 'http://www.apollo-blinds.co.uk/our-socials/twitter/', '58:e0a4c3987451f0c63c877818feebf38d', 60, 'post', 'our-socials', 1, 0, NULL, NULL, 'Twitter', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 16:05:18', '2023-01-31 16:05:23', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:05:23', '2023-01-31 16:05:23'),
(30, 'http://www.apollo-blinds.co.uk/our-socials/instagram/', '60:ee2ad4da0a6a7e6eaf15287ba672d7bd', 62, 'post', 'our-socials', 1, 0, NULL, NULL, 'Instagram', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 16:05:31', '2023-01-31 16:05:35', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:05:35', '2023-01-31 16:05:35'),
(31, 'http://www.apollo-blinds.co.uk/our-socials/linkedin/', '59:ab3abe6de1482a2894b4fa0d708dd4dd', 64, 'post', 'our-socials', 1, 0, NULL, NULL, 'LinkedIn', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 16:07:22', '2023-01-31 16:07:27', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:07:27', '2023-01-31 16:07:27'),
(32, 'http://www.apollo-blinds.co.uk/our-socials/youtube/', '58:952ce9ac9011a05132b924ad970fd9a6', 66, 'post', 'our-socials', 1, 0, NULL, NULL, 'YouTube', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-31 16:07:35', '2023-01-31 16:07:41', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:07:41', '2023-01-31 16:07:41'),
(33, 'http://www.apollo-blinds.co.uk/featured-banners/banner-4/', '64:6a17e9d0b4736f24a1d0bc9ebb7476f4', 69, 'post', 'featured-banners', 1, 0, NULL, NULL, 'Banner 4', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-blinds.jpg', NULL, '71', 'featured-image', NULL, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-blinds.jpg', '71', 'featured-image', '{"width":1080,"height":550,"filesize":65668,"url":"http:\\/\\/www.apollo-blinds.co.uk\\/wp-content\\/uploads\\/2023\\/01\\/home-office-blinds.jpg","path":"\\/Applications\\/MAMP\\/htdocs\\/2022\\/apollo2023\\/wp-content\\/uploads\\/2023\\/01\\/home-office-blinds.jpg","size":"full","id":71,"alt":"","pixels":594000,"type":"image\\/jpeg"}', 0, NULL, NULL, '2023-01-31 16:21:37', '2023-01-31 16:27:22', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-31 16:27:22', '2023-01-31 16:21:37'),
(34, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-blinds.jpg', '87:882932ec6bc16b2062be92f161e7d8e2', 71, 'post', 'attachment', 1, 36, NULL, NULL, 'home-office-blinds', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-blinds.jpg', NULL, '71', 'attachment-image', NULL, NULL, NULL, '71', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-31 16:26:33', '2023-01-31 16:26:33', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-31 16:26:33', '2023-01-31 16:26:33'),
(35, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-film-noir-venetian-blinds.jpg', '106:8b4d4c73aeb0307603721415200237c5', 72, 'post', 'attachment', 1, 36, NULL, NULL, 'home-office-film-noir-venetian-blinds', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-film-noir-venetian-blinds.jpg', NULL, '72', 'attachment-image', NULL, NULL, NULL, '72', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-31 16:26:33', '2023-01-31 16:26:33', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-31 16:26:33', '2023-01-31 16:26:33'),
(36, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-vertical-blinds.jpg', '96:ac0a364041d2504d8756084c7f978832', 73, 'post', 'attachment', 1, 36, NULL, NULL, 'home-office-vertical-blinds', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-vertical-blinds.jpg', NULL, '73', 'attachment-image', NULL, NULL, NULL, '73', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-31 16:26:34', '2023-01-31 16:26:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-31 16:26:34', '2023-01-31 16:26:34'),
(37, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-wooden-blinds.jpg', '94:e993883feccab53c787266ad17d6bb49', 74, 'post', 'attachment', 1, 36, NULL, NULL, 'home-office-wooden-blinds', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, NULL, 'http://www.apollo-blinds.co.uk/wp-content/uploads/2023/01/home-office-wooden-blinds.jpg', NULL, '74', 'attachment-image', NULL, NULL, NULL, '74', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-31 16:26:34', '2023-01-31 16:26:34', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-31 16:26:34', '2023-01-31 16:26:34') ;

#
# End of data contents of table `wp_yoast_indexable`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_indexable_hierarchy`
#

DROP TABLE IF EXISTS `wp_yoast_indexable_hierarchy`;


#
# Table structure of table `wp_yoast_indexable_hierarchy`
#

CREATE TABLE `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(11) unsigned NOT NULL,
  `ancestor_id` int(11) unsigned NOT NULL,
  `depth` int(11) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`indexable_id`,`ancestor_id`),
  KEY `indexable_id` (`indexable_id`),
  KEY `ancestor_id` (`ancestor_id`),
  KEY `depth` (`depth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_yoast_indexable_hierarchy`
#
INSERT INTO `wp_yoast_indexable_hierarchy` ( `indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(1, 0, 0, 1),
(2, 0, 0, 1),
(3, 0, 0, 1),
(4, 0, 0, 1),
(5, 0, 0, 1),
(9, 0, 0, 1),
(10, 0, 0, 1),
(11, 0, 0, 1),
(12, 0, 0, 1),
(13, 0, 0, 1),
(14, 0, 0, 1),
(15, 0, 0, 1),
(16, 0, 0, 1),
(17, 0, 0, 1),
(18, 0, 0, 1),
(19, 0, 0, 1),
(20, 0, 0, 1),
(21, 0, 0, 1),
(22, 0, 0, 1),
(23, 22, 1, 1),
(24, 0, 0, 1),
(25, 0, 0, 1),
(27, 0, 0, 1),
(28, 0, 0, 1),
(29, 0, 0, 1),
(30, 0, 0, 1),
(31, 0, 0, 1),
(32, 0, 0, 1),
(33, 0, 0, 1),
(34, 22, 1, 1),
(35, 22, 1, 1),
(36, 22, 1, 1),
(37, 22, 1, 1) ;

#
# End of data contents of table `wp_yoast_indexable_hierarchy`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_migrations`
#

DROP TABLE IF EXISTS `wp_yoast_migrations`;


#
# Table structure of table `wp_yoast_migrations`
#

CREATE TABLE `wp_yoast_migrations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wp_yoast_migrations_version` (`version`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_yoast_migrations`
#
INSERT INTO `wp_yoast_migrations` ( `id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404') ;

#
# End of data contents of table `wp_yoast_migrations`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_primary_term`
#

DROP TABLE IF EXISTS `wp_yoast_primary_term`;


#
# Table structure of table `wp_yoast_primary_term`
#

CREATE TABLE `wp_yoast_primary_term` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blog_id` bigint(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `post_taxonomy` (`post_id`,`taxonomy`),
  KEY `post_term` (`post_id`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_yoast_primary_term`
#

#
# End of data contents of table `wp_yoast_primary_term`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(11) unsigned DEFAULT NULL,
  `target_indexable_id` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`),
  KEY `indexable_link_direction` (`indexable_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`, `indexable_id`, `target_indexable_id`, `height`, `width`, `size`, `language`, `region`) VALUES
(1, 'http://www.apollo-blinds.co.uk/wp-admin/', 2, NULL, 'internal', 3, NULL, NULL, NULL, NULL, NULL, NULL) ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

